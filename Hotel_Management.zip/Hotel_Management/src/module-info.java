/**
 * 
 */
/**
 * @author User
 *
 */
module Hotel_Management {
	requires java.desktop;
	requires java.sql;
}