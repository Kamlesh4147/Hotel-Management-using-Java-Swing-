package com.hotelmanagement;

import com.hotelmanagement.services.Admincheck;
import com.hotelmanagement.services.Adminscreen;
import com.hotelmanagement.services.Checkinscreen;
import com.hotelmanagement.services.Checkoutscreen;
import com.hotelmanagement.services.Forgetpasswordscreen;
import com.hotelmanagement.services.Homepage;
import com.hotelmanagement.services.Loginpage;
import com.hotelmanagement.services.Manageroom;
import com.hotelmanagement.services.Registration;

public class Mainclass {

	public static void main(String[] args) {

		Loginpage login = new Loginpage();
//		Forgetpasswordscreen fp = new Forgetpasswordscreen();

	}

}
