package com.hotelmanagement.uicomponent;


import javax.swing.JLabel;

public class UILabel extends JLabel{
	public UILabel() {
		
	}
	
   public UILabel(String text) {
	   super(text);
   }
}
