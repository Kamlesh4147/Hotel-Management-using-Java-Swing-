package com.hotelmanagement.uicomponent;

import javax.swing.JMenu;

public class UIMenu extends JMenu{
	public UIMenu() {
		
	}
	public UIMenu(String text) {
		super(text);
	}

}
