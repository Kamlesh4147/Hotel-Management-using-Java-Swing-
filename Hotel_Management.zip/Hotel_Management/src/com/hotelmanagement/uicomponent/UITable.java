package com.hotelmanagement.uicomponent;

import javax.swing.JTable;

public class UITable extends JTable {

	public UITable() {
		super();
	}
	
}
