package com.hotelmanagement.uicomponent;

import javax.swing.JTextField;

public class UITextfield extends JTextField{
	public UITextfield() {
		
	}

}
