package com.hotelmanagement.uicomponent;

import javax.swing.JCheckBox;

public class UICheckbox extends JCheckBox {

	public UICheckbox() {
		super();
	}

}