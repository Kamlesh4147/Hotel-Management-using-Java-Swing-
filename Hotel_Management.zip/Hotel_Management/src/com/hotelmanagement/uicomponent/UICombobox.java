package com.hotelmanagement.uicomponent;

import java.util.List;

import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;

public class UICombobox extends JComboBox{

	public UICombobox() {
		super();
	}
	
	public UICombobox(List Text) {
		super();
	}
	
}
