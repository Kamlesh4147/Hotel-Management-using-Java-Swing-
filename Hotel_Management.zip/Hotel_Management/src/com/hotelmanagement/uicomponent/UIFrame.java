package com.hotelmanagement.uicomponent;

import javax.swing.JFrame;

public class UIFrame extends JFrame{
	public UIFrame() {
		
	}

	public UIFrame(String text) {
		super(text);
	}
}
