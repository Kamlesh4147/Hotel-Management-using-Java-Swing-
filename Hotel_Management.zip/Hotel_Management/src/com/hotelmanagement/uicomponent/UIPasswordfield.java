package com.hotelmanagement.uicomponent;

import javax.swing.JPasswordField;

public class UIPasswordfield extends JPasswordField{

	
	public UIPasswordfield() {
	}
}
