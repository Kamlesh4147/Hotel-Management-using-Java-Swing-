package com.hotelmanagement.uicomponent;

import javax.swing.JButton;

public class UIButton extends JButton{
	public UIButton() {
		super();
	}
	
	public UIButton(String text) {
		super(text);
	}

}
