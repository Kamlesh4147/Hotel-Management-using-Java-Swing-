package com.hotelmanagement.uicomponent;

import javax.swing.JMenuBar;

public class UIMenubar extends JMenuBar{
	
	public UIMenubar() {
	
	}

}
