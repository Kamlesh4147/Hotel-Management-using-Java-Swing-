package com.hotelmanagement.services;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.hotelmanagement.constants.Homeconstants;
import com.hotelmanagement.constants.Manageroomconstants;
import com.hotelmanagement.databaseconfiguration.Dbconnect;
import com.hotelmanagement.uicomponent.UIButton;
import com.hotelmanagement.uicomponent.UICombobox;
import com.hotelmanagement.uicomponent.UIFrame;
import com.hotelmanagement.uicomponent.UILabel;
import com.hotelmanagement.uicomponent.UITextfield;

public class Manageroom {

	public Manageroom() {

		String actype[] = { Manageroomconstants.AC_ROOM_TYPE, Manageroomconstants.NON_AC_ROOM_TYPE };

		String bedtype[] = { Manageroomconstants.SINGLE_BED_TYPE, Manageroomconstants.DOUBLE_BED_TYPE };

		UIFrame manageroomframe = new UIFrame(Manageroomconstants.MANAGE_ROOM);
		manageroomframe.setSize(750, 650);

		UIButton mbackbtn = new UIButton(Homeconstants.BACK_TO_HOME);
		mbackbtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		mbackbtn.setBackground(Color.red);
		mbackbtn.setForeground(Color.white);
		mbackbtn.setBounds(600, 20, 120, 25);

		UILabel managelabel = new UILabel(Manageroomconstants.MANAGE_ROOM);
		managelabel.setBounds(40, 20, 90, 25);

		UILabel roomnumnerlb = new UILabel(Manageroomconstants.ROOM_NUMBER);
		roomnumnerlb.setBounds(40, 380, 90, 25);

		UILabel roomtypelb = new UILabel(Manageroomconstants.ROOM_TYPE);
		roomtypelb.setBounds(400, 380, 90, 25);

		UITextfield roomnumbertxt = new UITextfield();
		roomnumbertxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		roomnumbertxt.setBounds(40, 415, 210, 25);

		JComboBox roomtypecombo = new JComboBox(actype);
		roomtypecombo.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		roomtypecombo.setSelectedIndex(-1);
		roomtypecombo.setBounds(400, 415, 210, 25);

		UILabel bedlb = new UILabel(Manageroomconstants.BED);
		bedlb.setBounds(40, 450, 90, 25);

		JComboBox bedcombo = new JComboBox(bedtype);
		bedcombo.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		bedcombo.setSelectedIndex(-1);
		bedcombo.setBounds(40, 485, 210, 25);

		UILabel pricelb = new UILabel(Manageroomconstants.PRICE);
		pricelb.setBounds(400, 450, 120, 25);

		UITextfield pricetxt = new UITextfield();
		pricetxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		pricetxt.setBounds(400, 485, 210, 25);

		UIButton addroombtn = new UIButton(Manageroomconstants.ADD_ROOM);
		addroombtn.setBorder(BorderFactory.createLineBorder(Color.blue));
		addroombtn.setBackground(Color.red);
		addroombtn.setForeground(Color.white);
		addroombtn.setBounds(520, 540, 100, 25);

		/** Table implementation starts */

		JTable managetable = new JTable();
		managetable.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		managetable.setBounds(40, 55, 650, 300);
		JScrollPane scrollpane = new JScrollPane(managetable);

		Object[] header = new Object[4];

		header[0] = Manageroomconstants.FIRST_HEADER;
		header[1] = Manageroomconstants.SECOND_HEADER;
		header[2] = Manageroomconstants.THIRD_HEADER;
		header[3] = Manageroomconstants.FOURTH_HEADER;

		managetable.setRowHeight(20);

		DefaultTableModel model = (DefaultTableModel) managetable.getModel();
		model.setColumnIdentifiers(header);
		model.addColumn(header);

		Object[] rows = new Object[4];

		Connection con = Dbconnect.getinstance();

		/**
		 * --action perform for 'Back To Home' button -- after click on 'Back To Home'
		 * button running frame will dispose and Homepage frame will open
		 */

		mbackbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				manageroomframe.dispose();

				Homepage homepage = new Homepage();

			}
		});

		/**
		 * action perform to 'add room' button so that all field data will add in table
		 * 
		 */

		addroombtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (roomnumbertxt.getText().equals("") || roomtypecombo.getSelectedItem().toString().equals("")
						|| bedcombo.getSelectedItem().toString().equals("") || pricetxt.getText().equals("")) {

					JOptionPane.showMessageDialog(manageroomframe, Manageroomconstants.ENTER_ALLFIELD_MESSAGE);

				} else {

					rows[0] = roomnumbertxt.getText();
					rows[1] = roomtypecombo.getSelectedItem().toString();
					rows[2] = bedcombo.getSelectedItem().toString();
					rows[3] = pricetxt.getText();

					model.setColumnIdentifiers(rows);
					model.addRow(rows);
					int statusId = 0;

					try {
						String query = "select id from status_table where status_code = 'NOT_BOOKED'";
						Statement stmnt = con.createStatement();
						ResultSet rs = stmnt.executeQuery(query);

						while (rs.next()) {

							// Display values

							System.out.print("ID: " + rs.getInt("id"));
							statusId = rs.getInt("id");

						}

					} catch (Exception e2) {
						e2.printStackTrace();

					}

					try {
						String room_number = roomnumbertxt.getText();
						String room_type = roomtypecombo.getSelectedItem().toString();
						String bed = bedcombo.getSelectedItem().toString();
						String price = pricetxt.getText();

						String query = "insert into room_details (room_number, room_type, bed, room_status, price) values('"
								+ roomnumbertxt.getText() + "','" + roomtypecombo.getSelectedItem().toString() + "','"
								+ bedcombo.getSelectedItem().toString() + "','" + statusId + "','" + pricetxt.getText()
								+ "')";
						Statement stmnt = con.createStatement();
						int update = stmnt.executeUpdate(query);
						System.out.println(update);

					} catch (Exception e2) {
						e2.printStackTrace();
					}
					JOptionPane.showMessageDialog(manageroomframe, Manageroomconstants.RECORD_SAVED_MESSAGE);
					roomnumbertxt.setText("");
					roomtypecombo.setSelectedIndex(-1);
					bedcombo.setSelectedIndex(-1);
					pricetxt.setText("");

				}

			}

		});

		manageroomframe.setUndecorated(true);
		manageroomframe.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		manageroomframe.add(scrollpane);
		manageroomframe.add(managetable);
		manageroomframe.add(mbackbtn);
		manageroomframe.add(managelabel);
		manageroomframe.add(managetable);
		manageroomframe.add(roomnumnerlb);
		manageroomframe.add(roomtypelb);
		manageroomframe.add(roomnumbertxt);
		manageroomframe.add(roomtypecombo);
		manageroomframe.add(bedlb);
		manageroomframe.add(bedcombo);
		manageroomframe.add(pricelb);
		manageroomframe.add(pricetxt);
		manageroomframe.add(addroombtn);

		manageroomframe.setLayout(null);
		manageroomframe.setVisible(true);
		manageroomframe.setEnabled(true);
		manageroomframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
