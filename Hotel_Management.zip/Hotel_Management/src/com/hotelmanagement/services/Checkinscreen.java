package com.hotelmanagement.services;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;

import com.hotelmanagement.constants.Checkinscreenconstants;
import com.hotelmanagement.databaseconfiguration.Dbconnect;
import com.hotelmanagement.uicomponent.UIButton;
import com.hotelmanagement.uicomponent.UIFrame;
import com.hotelmanagement.uicomponent.UILabel;
import com.hotelmanagement.uicomponent.UITextfield;

public class Checkinscreen {

	public Checkinscreen() {

		String genderdata[] = { Checkinscreenconstants.GENDER_MALE, Checkinscreenconstants.GENDER_FEMALE };

		String roomtypedata[] = { Checkinscreenconstants.AC_TYPE, Checkinscreenconstants.NON_AC_TYPE };

		String beddata[] = { Checkinscreenconstants.SINGLE_BED, Checkinscreenconstants.DOUBLE_BED };

		List<String> dataList = new ArrayList<>();

		UIFrame checkinframe = new UIFrame(Checkinscreenconstants.CUSTOMER_CHECK_IN1);

		UILabel customerlabel = new UILabel(Checkinscreenconstants.CUSTOMER_CHECK_IN2);
		customerlabel.setBounds(60, 20, 200, 20);

		UIButton cbacktohome = new UIButton(Checkinscreenconstants.Check_BACK_TO_HOME);
		cbacktohome.setBorder(BorderFactory.createLineBorder(Color.blue));
		cbacktohome.setBackground(Color.red);
		cbacktohome.setForeground(Color.white);
		cbacktohome.setBounds(550, 20, 120, 20);

		UILabel cnamelb = new UILabel(Checkinscreenconstants.CUSTOMER_NAME);
		cnamelb.setBounds(60, 70, 200, 20);

		UITextfield cnametext = new UITextfield();
		cnametext.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		cnametext.setBounds(60, 100, 200, 20);

		UILabel cmobnumberlb = new UILabel(Checkinscreenconstants.MOBILE_NUMBER);
		cmobnumberlb.setBounds(60, 140, 200, 20);

		UITextfield cmobilenumbertxt = new UITextfield();
		cmobilenumbertxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		cmobilenumbertxt.setBounds(60, 170, 200, 20);

		UILabel cemaillb = new UILabel(Checkinscreenconstants.EMAIL);
		cemaillb.setBounds(60, 210, 200, 20);

		UITextfield cemailtxt = new UITextfield();
		cemailtxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		cemailtxt.setBounds(60, 240, 200, 20);

		UILabel cgenderlb = new UILabel(Checkinscreenconstants.GENDER);
		cgenderlb.setBounds(60, 280, 200, 20);

		JComboBox gendercombo = new JComboBox(genderdata);
		gendercombo.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		gendercombo.setSelectedIndex(-1);
		gendercombo.setBounds(60, 310, 200, 20);

		UILabel cnationalitylb = new UILabel(Checkinscreenconstants.NATIONALITY);
		cnationalitylb.setBounds(60, 350, 200, 20);

		UITextfield cnationalitytxt = new UITextfield();
		cnationalitytxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		cnationalitytxt.setBounds(60, 380, 200, 20);

		UILabel caadharlb = new UILabel(Checkinscreenconstants.AADHAR_NUMBER);
		caadharlb.setBounds(60, 420, 200, 20);

		UITextfield caadhartxt = new UITextfield();
		caadhartxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		caadhartxt.setBounds(60, 450, 200, 20);

		UILabel caddresslb = new UILabel(Checkinscreenconstants.ADDRESS);
		caddresslb.setBounds(60, 480, 200, 20);

		UITextfield caddresstxt = new UITextfield();
		caddresstxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		caddresstxt.setBounds(60, 510, 200, 20);

		UILabel checkindatelb = new UILabel(Checkinscreenconstants.CHECK_IN_DATE);
		checkindatelb.setBounds(350, 70, 200, 20);

		UITextfield checkintxt = new UITextfield();
		checkintxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		checkintxt.setBounds(350, 100, 200, 20);

		UILabel roomtypelb = new UILabel(Checkinscreenconstants.ROOM_TYPE);
		roomtypelb.setBounds(350, 140, 200, 20);

		JComboBox roomtypecombo = new JComboBox(roomtypedata);
		roomtypecombo.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		roomtypecombo.setSelectedIndex(-1);
		roomtypecombo.setBounds(350, 170, 200, 20);

		UILabel bedlb = new UILabel(Checkinscreenconstants.BED);
		bedlb.setBounds(350, 210, 200, 20);

		JComboBox bedcombo = new JComboBox(beddata);
		bedcombo.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		bedcombo.setSelectedIndex(-1);
		bedcombo.setBounds(350, 240, 200, 20);

		UILabel roomnumberlb = new UILabel(Checkinscreenconstants.ROOM_NUMBER);
		roomnumberlb.setBounds(350, 280, 200, 20);

		UILabel pricelb = new UILabel(Checkinscreenconstants.PRICE);
		pricelb.setBounds(350, 350, 200, 20);

		UITextfield pricetxt = new UITextfield();
		pricetxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		pricetxt.setBounds(350, 380, 200, 20);

		UIButton alloterrombtn = new UIButton(Checkinscreenconstants.ALLOTTEE_ROOM);
		alloterrombtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		alloterrombtn.setBackground(Color.red);
		alloterrombtn.setForeground(Color.white);
		alloterrombtn.setBounds(370, 440, 120, 20);

		UIButton clearbtn = new UIButton(Checkinscreenconstants.CLEAR);
		clearbtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		clearbtn.setBackground(Color.red);
		clearbtn.setForeground(Color.white);
		clearbtn.setBounds(500, 440, 70, 20);

		Connection con = Dbconnect.getinstance();

		/**
		 * added the all room number to datalist so that it should reflect in room
		 * number combo box
		 */

		try {

			String q = "select room_number from room_details order by room_number asc;";
			Statement stmnt = con.createStatement();
			ResultSet result = stmnt.executeQuery(q);

			while (result.next()) {

				String data = result.getString("room_number");
				dataList.add(data);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		JComboBox<String> roomnumbercombo = new JComboBox<>(dataList.toArray(new String[dataList.size()]));
		roomnumbercombo.setSelectedIndex(-1);
		roomnumbercombo.setBounds(350, 310, 200, 20);

		/**
		 * --action perform for 'Back To Home' button -- after click on 'Back To Home'
		 * button, running frame will dispose and Homepage frame will open
		 */

		cbacktohome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				checkinframe.dispose();

				Homepage homepage = new Homepage();

			}
		});

		/**
		 * --action perform for 'Allote room' button -- By this action perform, operator
		 * allote room to perticular customer by clicking on 'allote room' button
		 */

		alloterrombtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (cnametext.getText().equals("") || cmobilenumbertxt.getText().equals("")
						|| cemailtxt.getText().equals("") || gendercombo.getSelectedItem().toString().equals("")
						|| cnationalitytxt.getText().equals("") || caadhartxt.getText().equals("")
						|| caddresstxt.getText().equals("") || checkintxt.getText().equals("")
						|| roomtypecombo.getSelectedItem().equals("")
						|| bedcombo.getSelectedItem().toString().equals("")
						|| roomnumbercombo.getSelectedItem().toString().equals("") || pricetxt.getText().equals("")) {

					JOptionPane.showMessageDialog(alloterrombtn, Checkinscreenconstants.ENTER_ALL_FIELD_MESSAGE);

				} else {

					int getid = 0;

					try {
						String getidquery = "select id from room_details where room_number='"
								+ roomnumbercombo.getSelectedItem().toString() + "'";
						Statement stmnt = con.createStatement();
						ResultSet resultgetid = stmnt.executeQuery(getidquery);

						while (resultgetid.next()) {

							getid = resultgetid.getInt("id");

						}

					} catch (Exception e2) {
						e2.printStackTrace();
					}

					try {

						String date = checkintxt.getText();
						SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
						java.util.Date dateStr = formatter.parse(date);
						java.sql.Date dateDB = new java.sql.Date(dateStr.getTime());

						String checkin_query = "insert into CheckIn(customer_name,checkInDate,mobile_number,room_type,email,bed,gender,room_number,nationality,pricePerDay,aadharCard,address) values('"
								+ cnametext.getText() + "','" + dateDB + "','" + cmobilenumbertxt.getText() + "','"
								+ roomtypecombo.getSelectedItem().toString() + "','" + cemailtxt.getText() + "','"
								+ bedcombo.getSelectedItem().toString() + "','"
								+ gendercombo.getSelectedItem().toString() + "','" + getid + "','"
								+ cnationalitytxt.getText() + "','" + pricetxt.getText() + "','" + caadhartxt.getText()
								+ "','" + caddresstxt.getText() + "')";
						Statement stmnt = con.createStatement();
						int update = stmnt.executeUpdate(checkin_query);
						System.out.println("Record inserted- " + update);

						JOptionPane.showMessageDialog(checkinframe, Checkinscreenconstants.RECORD_SAVED_MESSAGE);

					} catch (Exception e2) {
						e2.printStackTrace();
					}

				}
			}
		});

		/**
		 * --action perform for 'Clear' button Starts-- after clicking on clear button
		 * all fields will gets empty as before
		 */

		clearbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				cnametext.setText("");
				cmobilenumbertxt.setText("");
				cemailtxt.setText("");
				gendercombo.setSelectedIndex(-1);
				cnationalitytxt.setText("");
				caadhartxt.setText("");
				caddresstxt.setText("");
				checkintxt.setText("");
				roomtypecombo.setSelectedIndex(-1);
				bedcombo.setSelectedIndex(-1);
				roomnumbercombo.setSelectedIndex(-1);
				pricetxt.setText("");

			}
		});

		checkinframe.add(cbacktohome);
		checkinframe.add(customerlabel);
		checkinframe.add(cnamelb);
		checkinframe.add(cnametext);
		checkinframe.add(cmobnumberlb);
		checkinframe.add(cmobilenumbertxt);
		checkinframe.add(cemaillb);
		checkinframe.add(cemailtxt);
		checkinframe.add(cgenderlb);
		checkinframe.add(gendercombo);
		checkinframe.add(cnationalitylb);
		checkinframe.add(cnationalitytxt);
		checkinframe.add(caadharlb);
		checkinframe.add(caddresstxt);
		checkinframe.add(caddresslb);
		checkinframe.add(caadhartxt);

		checkinframe.add(checkindatelb);
		checkinframe.add(checkintxt);
		checkinframe.add(roomtypelb);
		checkinframe.add(roomtypecombo);
		checkinframe.add(bedlb);
		checkinframe.add(bedcombo);
		checkinframe.add(roomnumberlb);
		checkinframe.add(roomnumbercombo);
		checkinframe.add(pricelb);
		checkinframe.add(pricetxt);

		checkinframe.add(alloterrombtn);
		checkinframe.add(clearbtn);

		checkinframe.setUndecorated(true);
		checkinframe.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		checkinframe.setSize(700, 600);
		checkinframe.setLayout(null);
		checkinframe.setVisible(true);
		checkinframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
