package com.hotelmanagement.services;

import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.hotelmanagement.constants.Adminconstants;
import com.hotelmanagement.databaseconfiguration.Dbconnect;
import com.hotelmanagement.exceptionhandling.Adminscreenexception;
import com.hotelmanagement.uicomponent.UIButton;
import com.hotelmanagement.uicomponent.UIFrame;
import com.hotelmanagement.uicomponent.UILabel;
import com.hotelmanagement.uicomponent.UITextfield;

public class Adminscreen {

	public Adminscreen() {

		UIFrame frame = new UIFrame(Adminconstants.ADMIN_SCREEN);

		UILabel searchbyidbtn = new UILabel(Adminconstants.SEARCH_BY_EMAIL);
		searchbyidbtn.setBounds(180, 50, 100, 20);

		UITextfield searchbyemailtxt = new UITextfield();
		searchbyemailtxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		searchbyemailtxt.setBounds(290, 50, 140, 20);

		UIButton searchbtn = new UIButton(Adminconstants.SEARCH);
		searchbtn.setBorder(BorderFactory.createLineBorder(Color.blue));
		searchbtn.setBackground(Color.red);
		searchbtn.setForeground(Color.white);
		searchbtn.setBounds(450, 50, 75, 20);

		UIButton Refreshbtn = new UIButton(Adminconstants.REFRESH);
		Refreshbtn.setBorder(BorderFactory.createLineBorder(Color.blue));
		Refreshbtn.setBackground(Color.red);
		Refreshbtn.setForeground(Color.white);
		Refreshbtn.setBounds(540, 50, 80, 20);

		UIButton adminbacktohome = new UIButton(Adminconstants.BACK_TO_HOME);
		adminbacktohome.setBorder(BorderFactory.createLineBorder(Color.blue));
		adminbacktohome.setBackground(Color.red);
		adminbacktohome.setForeground(Color.white);
		adminbacktohome.setBounds(700, 50, 120, 20);

		Connection con = Dbconnect.getinstance();

		/** Table implementation in the admin screen */

		JTable table = new JTable();
		table.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		table.setBounds(40, 90, 800, 450);
		JScrollPane scrollpane = new JScrollPane(table);

		Object[] header = new Object[6];

		header[0] = Adminconstants.FIRST_HEADER;

		header[1] = Adminconstants.SECOND_HEADER;
		header[2] = Adminconstants.THIRD_HEADER;
		header[3] = Adminconstants.FOURTH_HEADER;
		header[4] = Adminconstants.FIFTH_HEADER;
		header[5] = Adminconstants.SIXTH_HEADER;

		table.setRowHeight(20);

		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setColumnIdentifiers(header);
		model.addColumn(header);

		/**
		 * --action perform for search button-- This action perform search the record
		 * based on email search
		 */

		searchbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (searchbyemailtxt.getText().equals("")) {

					JOptionPane.showMessageDialog(frame, Adminconstants.ENTER_EMAIL);

				} else {

					try {

						String query6 = "select * from users where email='" + searchbyemailtxt.getText() + "'";
						Statement stmnt = con.createStatement();
						ResultSet rs = stmnt.executeQuery(query6);

						String id, user_name, email, user_password, security_question, answer;
						while (rs.next()) {
							id = rs.getString(1);
							user_name = rs.getString(2);
							email = rs.getString(3);
							user_password = rs.getString(4);
							security_question = rs.getString(5);
							answer = rs.getString(6);

							String[] rows = { id, user_name, email, user_password, security_question, answer };
							model.addRow(rows);

							searchbyemailtxt.setText("");

						}

					} catch (SQLException ex) {
						ex.getStackTrace();
					}
				}
			}
		});

		/**
		 * --action perform for Refresh button starts-- after click on refresh button
		 * email text field should be empty
		 */

		Refreshbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (table.getSelectedRowCount() == 1) {

					model.removeRow(table.getSelectedRow());

					JOptionPane.showMessageDialog(frame, Adminconstants.RECORD_REFRESH);

				} else {
					JOptionPane.showMessageDialog(frame, Adminconstants.SELECT_REFRESH);
				}
				searchbyemailtxt.setText("");

			}
		});

		/**
		 * --action perform for 'Back To Home' button-- after click on 'Back To Home'
		 * button running frame will dispose and Homepage frame will open
		 */

		adminbacktohome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();

				Homepage homepage = new Homepage();

			}
		});

		frame.setUndecorated(true);
		frame.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		frame.add(adminbacktohome);
		frame.add(searchbyidbtn);
		frame.add(searchbyemailtxt);
		frame.add(searchbtn);
		frame.add(Refreshbtn);
		frame.add(table);
		frame.setSize(900, 650);
		frame.setLayout(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
