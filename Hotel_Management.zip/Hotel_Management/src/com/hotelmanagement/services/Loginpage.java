package com.hotelmanagement.services;

import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;

import com.hotelmanagement.constants.Loginconstants;
import com.hotelmanagement.constants.Logincredentialdetails;
import com.hotelmanagement.databaseconfiguration.Dbconnect;
import com.hotelmanagement.uicomponent.UIButton;
import com.hotelmanagement.uicomponent.UICheckbox;
import com.hotelmanagement.uicomponent.UIFrame;
import com.hotelmanagement.uicomponent.UILabel;
import com.hotelmanagement.uicomponent.UIPasswordfield;
import com.hotelmanagement.uicomponent.UITextfield;

public class Loginpage {

	public Loginpage() {

		UIFrame frame = new UIFrame(Loginconstants.LOGIN_FRAME);

		UILabel signin = new UILabel(Loginconstants.SIGN_IN);
		signin.setBounds(150, 50, 70, 25);

		UILabel emaillb = new UILabel(Loginconstants.EMAIL);
		emaillb.setBounds(60, 100, 75, 40);

		UILabel passwordlb = new UILabel(Loginconstants.PASSWORD);
		passwordlb.setBounds(60, 135, 75, 40);

		UITextfield emailtxt = new UITextfield();
		emailtxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		emailtxt.setBounds(155, 100, 160, 25);

		UIPasswordfield passwordtxt = new UIPasswordfield();
		passwordtxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		passwordtxt.setBounds(155, 135, 160, 25);

		UICheckbox showpassword = new UICheckbox();
		showpassword.setBounds(320, 135, 35, 35);

		UIButton loginbtn = new UIButton(Loginconstants.LOGIN);
		loginbtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		loginbtn.setBackground(Color.red);
		loginbtn.setForeground(Color.white);
		loginbtn.setBounds(60, 190, 70, 25);

		UIButton sinupnowbtn = new UIButton(Loginconstants.SIGNUP);
		sinupnowbtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		sinupnowbtn.setBackground(Color.red);
		sinupnowbtn.setForeground(Color.white);
		sinupnowbtn.setBounds(140, 190, 110, 25);

		UIButton forgetpassbtn = new UIButton(Loginconstants.FORGET_PASS);
		forgetpassbtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		forgetpassbtn.setBackground(Color.red);
		forgetpassbtn.setForeground(Color.white);
		forgetpassbtn.setBounds(260, 190, 120, 25);

		/**
		 * Action perform for sin up button so that running frame will be dispose and
		 * Registration will be open
		 */

		sinupnowbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				frame.dispose();

				Registration registration = new Registration();

			}
		});

		/**
		 * Action perform to login button so that Homepage frame will be open if user
		 * credentials are correct
		 */
		
		loginbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String s1 = Logincredentialdetails.LOGIN_USERNAME;

				String s2 = Logincredentialdetails.LOGIN_PASSWORD;

				if (s1.equals(emailtxt.getText()) && s2.equals(passwordtxt.getText())) {
					frame.dispose();
					Homepage homepage = new Homepage();

					JOptionPane.showMessageDialog(loginbtn, Loginconstants.LOGIN_SUCCESSFUL_MESSAGE);

				} else {

					JOptionPane.showMessageDialog(loginbtn, Loginconstants.WRONG_CREDENTIAL_MESSAGE);

				}

			}
		});

		/**
		 * Action perform for show and hide password
		 * 
		 */

		showpassword.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (showpassword.isSelected()) {
					passwordtxt.setEchoChar((char) 0);
				} else {
					passwordtxt.setEchoChar('*');
				}

			}
		});

		frame.add(emaillb);
		frame.add(passwordlb);
		frame.add(emailtxt);
		frame.add(passwordtxt);
		frame.add(showpassword);
		frame.add(loginbtn);
		frame.add(sinupnowbtn);
		frame.add(forgetpassbtn);
		frame.add(signin);

		frame.setUndecorated(true);
		frame.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 400);
		frame.setLayout(null);
		frame.setVisible(true);
	}
}
