package com.hotelmanagement.services;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;

import com.hotelmanagement.constants.Homeconstants;
import com.hotelmanagement.uicomponent.UIButton;
import com.hotelmanagement.uicomponent.UIFrame;
import com.hotelmanagement.uicomponent.UIMenu;

public class Homepage {

	public Homepage() {

		UIFrame homeframe = new UIFrame(Homeconstants.HOME_FRAME);

		JMenuBar menubar = new JMenuBar();

		JMenuItem item1 = new JMenuItem(Homeconstants.ITEM1_OPEN);
		item1.setBorder(BorderFactory.createLineBorder(Color.blue));
		JMenuItem item2 = new JMenuItem(Homeconstants.ITEM2_OPEN);
		item2.setBorder(BorderFactory.createLineBorder(Color.blue));
		JMenuItem item3 = new JMenuItem(Homeconstants.ITEM3_OPEN);
		item3.setBorder(BorderFactory.createLineBorder(Color.blue));
		JMenuItem item4 = new JMenuItem(Homeconstants.ITEM4_OPEN);
		item4.setBorder(BorderFactory.createLineBorder(Color.blue));

		UIMenu menu1 = new UIMenu(Homeconstants.MANAGE_ROOM);
		menu1.setBorder(BorderFactory.createLineBorder(Color.blue));
		UIMenu menu2 = new UIMenu(Homeconstants.CUSTOMER_CHECKIN);
		menu2.setBorder(BorderFactory.createLineBorder(Color.blue));
		UIMenu menu3 = new UIMenu(Homeconstants.CUSTOMER_CHECKOUT);
		menu3.setBorder(BorderFactory.createLineBorder(Color.blue));
		UIMenu menu4 = new UIMenu(Homeconstants.ADMIN_SCREEN);
		menu4.setBorder(BorderFactory.createLineBorder(Color.blue));

		menu1.add(item1);
		menu2.add(item2);
		menu3.add(item3);
		menu4.add(item4);

		UIButton logoutbtn = new UIButton(Homeconstants.LOGOUT);
		logoutbtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		logoutbtn.setFont(new Font("Monaco", Font.BOLD, 10));
		logoutbtn.setBackground(Color.red);
		logoutbtn.setForeground(Color.white);
		logoutbtn.setBounds(390, 400, 90, 20);

		/** Action perform to open manage screen from home page * */

		item1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				homeframe.dispose();
				Manageroom manageroom = new Manageroom();
			}
		});

		/** Action perform to open check in screen from home page * */

		item2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				homeframe.dispose();
				Checkinscreen checkin = new Checkinscreen();
			}
		});

		/** Action perform to open check out screen from home page * */

		item3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				homeframe.dispose();
				Checkoutscreen checkout = new Checkoutscreen();
			}
		});

		/**
		 * Action perform to open Admin check screen from home page (Admin check
		 * screen-This screen only provide access to admin so that only admin can able
		 * to open admin screnn) *
		 */

		item4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				homeframe.dispose();
				JOptionPane.showMessageDialog(homeframe, "Only admin can access this screen..!");
				Admincheck admincheck = new Admincheck();
			}
		});

		/**
		 * Action perform to open Admin check screen from home page (Admin check
		 * screen-This screen only provide access to admin so that only admin can able
		 * to open admin screnn) *
		 */

		logoutbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				homeframe.dispose();
				Loginpage login = new Loginpage();
				JOptionPane.showMessageDialog(logoutbtn, Homeconstants.LOGOUT_MESSAGE);

			}
		});

		menubar.add(menu1);
		menubar.add(menu2);
		menubar.add(menu3);
		menubar.add(menu4);

		homeframe.setJMenuBar(menubar);
		homeframe.add(logoutbtn);

		homeframe.setUndecorated(true);
		homeframe.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		homeframe.setLayout(null);
		homeframe.setSize(500, 500);

		homeframe.setVisible(true);

	}
}
