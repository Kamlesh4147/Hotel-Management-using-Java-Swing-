package com.hotelmanagement.services;

import java.awt.BorderLayout;
import java.awt.Color;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.hotelmanagement.constants.Checkoutscreenconstants;
import com.hotelmanagement.databaseconfiguration.Dbconnect;
import com.hotelmanagement.uicomponent.UIButton;
import com.hotelmanagement.uicomponent.UIFrame;
import com.hotelmanagement.uicomponent.UILabel;
import com.hotelmanagement.uicomponent.UITable;
import com.hotelmanagement.uicomponent.UITextfield;

public class Checkoutscreen {

	public Checkoutscreen() {

		UIFrame checkoutframe = new UIFrame(Checkoutscreenconstants.CUSTOMER_CHECKOUT);

		UILabel roomnumberlb = new UILabel(Checkoutscreenconstants.ROOM_NUMBER);
		roomnumberlb.setBounds(200, 40, 90, 20);

		UITextfield roomnumertxt = new UITextfield();
		roomnumertxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		roomnumertxt.setBounds(300, 40, 70, 20);

		UIButton searchbtn1 = new UIButton(Checkoutscreenconstants.SEARCH);
		searchbtn1.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		searchbtn1.setBackground(Color.red);
		searchbtn1.setForeground(Color.white);
		searchbtn1.setBounds(380, 40, 77, 20);

		UIButton checkoutbacktohomebtn = new UIButton(Checkoutscreenconstants.CHECKOUT_BACK_TO_HOME);
		checkoutbacktohomebtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		checkoutbacktohomebtn.setBackground(Color.red);
		checkoutbacktohomebtn.setForeground(Color.white);
		checkoutbacktohomebtn.setBounds(550, 40, 120, 20);

		UILabel customernamelb = new UILabel(Checkoutscreenconstants.CUSTOMER_NAME);
		customernamelb.setBounds(40, 100, 120, 20);

		UITextfield customernametxt = new UITextfield();
		customernametxt.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));
		customernametxt.setBounds(40, 130, 140, 20);

		UILabel priceperdaylb = new UILabel(Checkoutscreenconstants.PRICE_PER_DAY);
		priceperdaylb.setBounds(40, 170, 120, 20);

		UITextfield priceperdaytxt = new UITextfield();
		priceperdaytxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		priceperdaytxt.setBounds(40, 200, 140, 20);

		UILabel checkindatelb = new UILabel(Checkoutscreenconstants.CHECK_IN_DATE);
		checkindatelb.setBounds(40, 240, 120, 20);

		UITextfield checkindatetxt = new UITextfield();
		checkindatetxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		checkindatetxt.setBounds(40, 270, 140, 20);

		UILabel customermobilenumberlb = new UILabel(Checkoutscreenconstants.CUSTOMER_MOBILE_NUMEBR);
		customermobilenumberlb.setBounds(240, 100, 150, 20);

		UITextfield customermobilenumbertxt = new UITextfield();
		customermobilenumbertxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		customermobilenumbertxt.setBounds(240, 130, 140, 20);

		UILabel nummberofdayslb = new UILabel(Checkoutscreenconstants.NUMBER_OF_DAYS);
		nummberofdayslb.setBounds(240, 170, 120, 20);

		UITextfield nummberofdaystxt = new UITextfield();
		nummberofdaystxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		nummberofdaystxt.setBounds(240, 200, 140, 20);

		UILabel checkoutdatelb = new UILabel(Checkoutscreenconstants.CHECK_OUT_DATE);
		checkoutdatelb.setBounds(240, 240, 150, 20);

		UITextfield checkoutdatetxt = new UITextfield();
		checkoutdatetxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		checkoutdatetxt.setBounds(240, 270, 140, 20);

		UILabel emailcheckoutlb = new UILabel(Checkoutscreenconstants.EMAIL);
		emailcheckoutlb.setBounds(470, 100, 120, 20);

		UITextfield emailcheckouttxt = new UITextfield();
		emailcheckouttxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		emailcheckouttxt.setBounds(470, 130, 140, 20);

		UILabel totalamountlb = new UILabel(Checkoutscreenconstants.TOTAL_AMOUNT_TO_COLLECT);
		totalamountlb.setBounds(470, 170, 160, 20);

		UITextfield totalamounttxt = new UITextfield();
		totalamounttxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		totalamounttxt.setBounds(470, 200, 140, 20);

		UIButton checkoutbtn = new UIButton(Checkoutscreenconstants.CHECKOUT);
		checkoutbtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		checkoutbtn.setBackground(Color.red);
		checkoutbtn.setForeground(Color.white);
		checkoutbtn.setBounds(470, 260, 100, 20);

		UIButton clearbtn1 = new UIButton(Checkoutscreenconstants.CLEAR);
		clearbtn1.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		clearbtn1.setBackground(Color.red);
		clearbtn1.setForeground(Color.white);
		clearbtn1.setBounds(590, 260, 70, 20);

		Connection con = Dbconnect.getinstance();

		/** Table implementation in the checkout screen start */

		JTable checkouttable = new JTable();
		checkouttable.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		checkouttable.setBounds(20, 300, 650, 230);
		JScrollPane scrollpane = new JScrollPane(checkouttable);

		Object[] header = new Object[12];
		header[0] = Checkoutscreenconstants.FIRST_HEADER;
		header[1] = Checkoutscreenconstants.SECOND_HEADER;
		header[2] = Checkoutscreenconstants.THIRD_HEADER;
		header[3] = Checkoutscreenconstants.FOURTH_HEADER;
		header[4] = Checkoutscreenconstants.FIFTH_HEADER;
		header[5] = Checkoutscreenconstants.SIXTH_HEADER;
		header[6] = Checkoutscreenconstants.SEVENH_HEADER;
		header[7] = Checkoutscreenconstants.EIGHTH_HEADER;
		header[8] = Checkoutscreenconstants.NINETH_HEADER;
		header[9] = Checkoutscreenconstants.TENTH_HEADER;
		header[10] = Checkoutscreenconstants.ELEVENTH_HEADER;
		header[11] = Checkoutscreenconstants.TWELVETH_HEADER;

		checkouttable.setRowHeight(20);

		DefaultTableModel model = (DefaultTableModel) checkouttable.getModel();
		model.setColumnIdentifiers(header);
		model.addColumn(header);

		/**
		 * Taking all data from check in table from database and Stored in rowall String
		 * type array
		 * 
		 */

		try {

			String query8 = "select * from CheckIn";
			Statement stmnt = con.createStatement();
			ResultSet resultSet = stmnt.executeQuery(query8);
			java.sql.ResultSetMetaData rsmd = resultSet.getMetaData();

			while (resultSet.next()) {
				String Id = resultSet.getString(1);
				String Customer_name = resultSet.getString(2);
				String CheckInDate = resultSet.getString(3);
				String Mobile_number = resultSet.getString(4);
				String Room_type = resultSet.getString(5);
				String Email = resultSet.getString(6);
				String Bed = resultSet.getString(7);
				String Gender = resultSet.getString(8);
				String Room_number = resultSet.getString(9);
				String Nationality = resultSet.getString(10);
				String PricePerDay = resultSet.getString(11);
				String AadharCard = resultSet.getString(12);
				String Address = resultSet.getString(13);

				String[] rowall = { Id, Customer_name, CheckInDate, Mobile_number, Room_type, Email, Bed, Gender,
						Room_number, Nationality, PricePerDay, AadharCard, Address };
				model.addRow(rowall);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		/**
		 * --action perform for 'Back To Home' button -- after click on 'Back To Home'
		 * button running frame will dispose and Homepage frame will open
		 */

		checkoutbacktohomebtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				checkoutframe.dispose();
				Homepage homepage = new Homepage();

			}
		});

		/**
		 * --action perform for 'Search' button -- after click on 'Search' button data
		 * should be come in table search by particular id
		 */

		searchbtn1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (roomnumertxt.getText().equals("")) {

					JOptionPane.showMessageDialog(checkoutframe, "Enter the id first..!");

				} else {

					for (int row = 0; row < checkouttable.getRowCount(); row++) {
						model.removeRow(row);
					}

					try {
						String query7 = "select * from CheckIn where room_number='" + roomnumertxt.getText() + "'";
						Statement stmnt = con.createStatement();
						ResultSet result = stmnt.executeQuery(query7);
						while (result.next()) {

							String id = result.getString(1);
							String customer_name = result.getString(2);
							String checkInDate = result.getString(3);
							String mobile_number = result.getString(4);
							String room_type = result.getString(5);
							String email = result.getString(6);
							String bed = result.getString(7);
							String gender = result.getString(8);
							String room_number = result.getString(9);
							String nationality = result.getString(10);
							String pricePerDay = result.getString(11);
							String aadharCard = result.getString(12);
							String address = result.getString(13);

							String[] rows = { id, customer_name, checkInDate, mobile_number, room_type, email, bed,
									gender, room_number, nationality, pricePerDay, aadharCard, address };
							model.addRow(rows);

							customernametxt.setText(customer_name);
							priceperdaytxt.setText(pricePerDay);
							checkindatetxt.setText(checkInDate);
							customermobilenumbertxt.setText(mobile_number);
							emailcheckouttxt.setText(email);

						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}

				}
			}

		});

		/**
		 * Auto Multiplication between of two string (i.e-multiplication between price
		 * per day * number of days)
		 * 
		 */

		totalamounttxt.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {

				String str1 = priceperdaytxt.getText().toString();
				String str2 = nummberofdaystxt.getText().toString();

				Double result = Double.parseDouble(str1) * Double.parseDouble(str2);

				String s = String.valueOf(result);
				totalamounttxt.setText(s);

			}
		});

		checkoutframe.add(roomnumberlb);
		checkoutframe.add(roomnumertxt);
		checkoutframe.add(searchbtn1);
		checkoutframe.add(checkoutbacktohomebtn);
		checkoutframe.add(customernamelb);
		checkoutframe.add(customernametxt);
		checkoutframe.add(priceperdaylb);
		checkoutframe.add(priceperdaytxt);
		checkoutframe.add(customermobilenumberlb);
		checkoutframe.add(customermobilenumbertxt);
		checkoutframe.add(nummberofdayslb);
		checkoutframe.add(nummberofdaystxt);
		checkoutframe.add(checkindatelb);
		checkoutframe.add(checkindatetxt);
		checkoutframe.add(checkoutdatelb);
		checkoutframe.add(checkoutdatetxt);
		checkoutframe.add(emailcheckoutlb);
		checkoutframe.add(emailcheckouttxt);
		checkoutframe.add(totalamountlb);
		checkoutframe.add(totalamounttxt);
		checkoutframe.add(checkoutbtn);
		checkoutframe.add(clearbtn1);
		checkoutframe.add(checkouttable);

		checkoutframe.setUndecorated(true);
		checkoutframe.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		checkoutframe.setSize(700, 600);
		checkoutframe.setLayout(null);
		checkoutframe.setVisible(true);
		checkoutframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
