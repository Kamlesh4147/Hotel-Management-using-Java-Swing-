package com.hotelmanagement.services;

import java.awt.Color;


import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;

import com.hotelmanagement.constants.Admincheckconstants;
import com.hotelmanagement.constants.Adminconstants;
import com.hotelmanagement.constants.Admincredentials;
import com.hotelmanagement.constants.Loginconstants;
import com.hotelmanagement.databaseconfiguration.Dbconnect;
import com.hotelmanagement.uicomponent.UIButton;
import com.hotelmanagement.uicomponent.UICheckbox;
import com.hotelmanagement.uicomponent.UIFrame;
import com.hotelmanagement.uicomponent.UILabel;
import com.hotelmanagement.uicomponent.UIPasswordfield;
import com.hotelmanagement.uicomponent.UITextfield;

public class Admincheck {

	public Admincheck() {

		UIFrame frame = new UIFrame(Admincheckconstants.ADMIN_VERIFY);

		UILabel signin = new UILabel(Admincheckconstants.ADMIN_SIGN);
		signin.setBounds(150, 50, 90, 25);

		UIButton adminbacktohome = new UIButton(Admincheckconstants.ADMIN_BACK_TO_LOGIN);
		adminbacktohome.setBorder(BorderFactory.createLineBorder(Color.blue));
		adminbacktohome.setBackground(Color.red);
		adminbacktohome.setForeground(Color.white);
		adminbacktohome.setBounds(250, 320, 120, 25);

		UILabel emaillb = new UILabel(Admincheckconstants.ADMIN_EMAIL);
		emaillb.setBounds(60, 100, 75, 40);

		UILabel passwordlb = new UILabel(Admincheckconstants.ADMIN_PASSWORD);
		passwordlb.setBounds(60, 135, 75, 40);

		UITextfield emailtxt = new UITextfield();
		emailtxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		emailtxt.setBounds(155, 100, 160, 25);

		UIPasswordfield passwordtxt = new UIPasswordfield();
		passwordtxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		passwordtxt.setBounds(155, 135, 160, 25);

		UICheckbox hidepass = new UICheckbox();
		hidepass.setBounds(320, 135, 35, 35);

		UIButton loginbtn = new UIButton(Admincheckconstants.ADMIN_LOGIN_BTN);
		loginbtn.setBorder(BorderFactory.createLineBorder(Color.blue));
		loginbtn.setBackground(Color.red);
		loginbtn.setForeground(Color.white);
		loginbtn.setBounds(170, 190, 70, 25);

		/**
		 * -- action perform for 'Login' button -- login functionality for admin screen
		 */

		loginbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String s1 = Admincredentials.ADMIN_USERNAME;

				String s2 = Admincredentials.ADMIN_PASSWORD;

				if (s1.equals(emailtxt.getText()) && s2.equals(passwordtxt.getText())) {
					frame.dispose();
					Adminscreen admin = new Adminscreen();

					JOptionPane.showMessageDialog(loginbtn, Admincheckconstants.ADMIN_LOGIN_SUCCESS_MESSAGE);

				} else {

					JOptionPane.showMessageDialog(loginbtn, Admincheckconstants.ADMIN_LOGIN_FAILED_MESSAGE);

				}

			}
		});

		/**
		 * --action perform for 'Back To Home' button -- after click on 'Back To Home'
		 * button running frame will dispose and Homepage frame will open
		 */

		adminbacktohome.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Homepage homepage = new Homepage();

			}
		});

		/**
		 * Action perform for show and hide password for Admin check screen
		 * 
		 */

		hidepass.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (hidepass.isSelected()) {
					passwordtxt.setEchoChar((char) 0);
				} else {
					passwordtxt.setEchoChar('*');

				}
			}
		});

		frame.add(emaillb);
		frame.add(passwordlb);
		frame.add(emailtxt);
		frame.add(passwordtxt);
		frame.add(hidepass);
		frame.add(loginbtn);
		frame.add(signin);
		frame.add(adminbacktohome);

		frame.setUndecorated(true);
		frame.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 400);
		frame.setLayout(null);
		frame.setVisible(true);
	}
}
