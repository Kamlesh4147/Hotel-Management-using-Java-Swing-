package com.hotelmanagement.services;

import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;

import com.hotelmanagement.constants.Registrationconstants;
import com.hotelmanagement.databaseconfiguration.Dbconnect;
import com.hotelmanagement.uicomponent.UIButton;
import com.hotelmanagement.uicomponent.UICheckbox;
import com.hotelmanagement.uicomponent.UICombobox;
import com.hotelmanagement.uicomponent.UIFrame;
import com.hotelmanagement.uicomponent.UILabel;
import com.hotelmanagement.uicomponent.UIPasswordfield;
import com.hotelmanagement.uicomponent.UITextfield;

public class Registration {

	public Registration() {

		String securitydata[] = { Registrationconstants.SECURITY_QUESTION1, Registrationconstants.SECURITY_QUESTION2,
				Registrationconstants.SECURITY_QUESTION3, Registrationconstants.SECURITY_QUESTION4 };

		UIFrame regframe = new UIFrame(Registrationconstants.REGISTRATION_PAGE);

		UILabel namelb = new UILabel(Registrationconstants.NAME);
		namelb.setBounds(160, 120, 70, 20);

		UILabel emaillabel = new UILabel(Registrationconstants.EMAIL);
		emaillabel.setBounds(160, 160, 70, 20);

		UILabel passwordlb = new UILabel(Registrationconstants.PASSWORD);
		passwordlb.setBounds(160, 200, 70, 20);

		UILabel securitylb = new UILabel(Registrationconstants.SECURITY_QUESTION);
		securitylb.setBounds(160, 240, 120, 20);

		UILabel answerlb = new UILabel(Registrationconstants.ANSWER);
		answerlb.setBounds(160, 280, 100, 20);

		UITextfield nametext = new UITextfield();
		nametext.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		nametext.setBounds(290, 120, 175, 20);

		UITextfield passwordtext = new UITextfield();
		passwordtext.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		passwordtext.setBounds(290, 160, 175, 20);

		UICheckbox showpasscheckbox = new UICheckbox();
		showpasscheckbox.setBounds(470, 195, 35, 35);

		UIPasswordfield passtext = new UIPasswordfield();
		passtext.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		passtext.setBounds(290, 200, 175, 20);

		JComboBox securitycombo = new JComboBox(securitydata);
		securitycombo.setSelectedIndex(-1);
		securitycombo.setBounds(290, 240, 175, 20);

		UITextfield answertext = new UITextfield();
		answertext.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		answertext.setBounds(290, 280, 175, 20);

		UIButton signupbtn = new UIButton(Registrationconstants.SIGNUP1);
		signupbtn.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		signupbtn.setBackground(Color.red);
		signupbtn.setForeground(Color.white);
		signupbtn.setBounds(220, 320, 75, 25);

		UIButton backtologin = new UIButton(Registrationconstants.BACK_TO_LOGIN);
		backtologin.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		backtologin.setBackground(Color.red);
		backtologin.setForeground(Color.white);
		backtologin.setBounds(310, 320, 120, 25);

		UILabel signuplabel = new UILabel(Registrationconstants.SIGNUP2);
		signuplabel.setBounds(300, 70, 70, 20);

		Connection con = Dbconnect.getinstance();

		/**
		 * --action perform for 'Back To Home' button -- after click on 'Back To Home'
		 * button running frame will dispose and Homepage frame will open
		 */

		backtologin.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				regframe.dispose();
				Loginpage login = new Loginpage();
			}
		});

		/**
		 * --action perform for 'Sign Up' button --It is for customer registration
		 * 
		 */

		signupbtn.addActionListener(new ActionListener() {

			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent e) {

				if (nametext.getText().equals("") || passwordtext.getText().equals("") || passtext.getText().equals("")
						|| securitycombo.getSelectedItem().toString().equals("") || answertext.getText().equals("")) {

					JOptionPane.showMessageDialog(signupbtn, Registrationconstants.ENTER_ALL_FIELD_MESSAGE);
				} else {
					try {

						String query1 = "insert into users (user_name,email,user_password,security_question,answer) values ('"
								+ nametext.getText() + "','" + passwordtext.getText() + "','" + passtext.getText()
								+ "','" + securitycombo.getSelectedItem().toString() + "','" + answertext.getText()
								+ "')";
						Statement stmnt = con.createStatement();
						int update = stmnt.executeUpdate(query1);

						System.out.println("Record saved" + update);

						JOptionPane.showMessageDialog(regframe,
								"Thanks '" + nametext.getText() + "'" + '\n' + "You Registered successfully..!");

						nametext.setText("");
						passwordtext.setText("");
						passtext.setText("");
						securitycombo.setSelectedIndex(-1);
						answertext.setText("");

					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}

			}
		});

		/**
		 * Action perform for show and hide password
		 */

		showpasscheckbox.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (showpasscheckbox.isSelected()) {
					passtext.setEchoChar((char) 0);
				} else {
					passtext.setEchoChar('*');
				}

			}
		});

		regframe.add(signuplabel);
		regframe.add(namelb);
		regframe.add(emaillabel);
		regframe.add(passwordlb);
		regframe.add(securitylb);
		regframe.add(answerlb);
		regframe.add(answerlb);
		regframe.add(nametext);
		regframe.add(passwordtext);
		regframe.add(securitycombo);
		regframe.add(passtext);
		regframe.add(showpasscheckbox);
		regframe.add(answertext);
		regframe.add(signupbtn);
		regframe.add(backtologin);

		regframe.setUndecorated(true);
		regframe.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		regframe.setSize(675, 500);
		regframe.setEnabled(true);
		regframe.setLayout(null);
		regframe.setVisible(true);
		regframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
