package com.hotelmanagement.services;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import com.hotelmanagement.constants.Forgetscreenconstants;
import com.hotelmanagement.databaseconfiguration.Dbconnect;
import com.hotelmanagement.uicomponent.UIButton;
import com.hotelmanagement.uicomponent.UIFrame;
import com.hotelmanagement.uicomponent.UILabel;
import com.hotelmanagement.uicomponent.UITextfield;

public class Forgetpasswordscreen {

	public Forgetpasswordscreen() {

		String[] securityquestiondata = { Forgetscreenconstants.SECURITY_QUESTION1,
				Forgetscreenconstants.SECURITY_QUESTION2, Forgetscreenconstants.SECURITY_QUESTION3,
				Forgetscreenconstants.SECURITY_QUESTION4 };

		UIFrame frame = new UIFrame(Forgetscreenconstants.FRAME_NAME);

		UILabel emaillb = new UILabel(Forgetscreenconstants.EMAIL);
		emaillb.setBounds(50, 100, 50, 20);

		UITextfield emailtxt = new UITextfield();
		emailtxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		emailtxt.setBounds(170, 100, 150, 20);

		UILabel securityquestionlb = new UILabel(Forgetscreenconstants.SECURITY_QUESTION);
		securityquestionlb.setBounds(50, 140, 110, 20);

		JComboBox securitycombo = new JComboBox(securityquestiondata);
		securitycombo.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		securitycombo.setSelectedIndex(-1);
		securitycombo.setBounds(170, 140, 150, 20);

		UILabel securityanswerlb = new UILabel(Forgetscreenconstants.ANSWER);
		securityanswerlb.setBounds(50, 180, 60, 20);

		UITextfield answertxt = new UITextfield();
		answertxt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		answertxt.setBounds(170, 180, 150, 20);

		UIButton changepasslb = new UIButton(Forgetscreenconstants.CHANGE_PASSWORD);
		changepasslb.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		changepasslb.setBackground(Color.red);
		changepasslb.setForeground(Color.white);
		changepasslb.setBounds(130, 230, 135, 20);

		Connection con = Dbconnect.getinstance();

		/**
		 * get the data from users table
		 * 
		 */

//		try {
//			String query = "select * from users where email,security_question,answer='" + emailtxt.getText() + "','"
//					+ securitycombo.getSelectedItem().toString() + "','" + answertxt.getText() + "'";
//			Statement stmnt = con.createStatement();
//			ResultSet resultSet = stmnt.executeQuery(query);
//
//			while (resultSet.next()) {
//				String email = resultSet.getString(1);
//				String securityquestion = resultSet.getString(2);
//				String answer = resultSet.getString(3);
//
//				String[] data = { email, securityquestion, answer };
//
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		changepasslb.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
			}
		});

		frame.add(emaillb);
		frame.add(emailtxt);
		frame.add(securitycombo);
		frame.add(securityquestionlb);
		frame.add(securityanswerlb);
		frame.add(answertxt);
		frame.add(changepasslb);
		frame.setSize(400, 400);
		frame.setLayout(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}
