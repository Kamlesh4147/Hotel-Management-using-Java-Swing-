package com.hotelmanagement.databaseconfiguration;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbconnect {

	static Connection con = null;

	private Dbconnect() {

	}

	public static Connection getinstance() {

		try {

			if (con == null) {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Hotel_Management?useSSL=false", "root",
						"root");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return con;
	}

}
