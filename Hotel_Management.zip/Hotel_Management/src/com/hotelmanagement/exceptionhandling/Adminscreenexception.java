package com.hotelmanagement.exceptionhandling;

public class Adminscreenexception extends Exception{
	
	public Adminscreenexception(String str) {
		super(str);
	}

}

