package com.hotelmanagement.constants;

public class Registrationconstants {

	public static String REGISTRATION_PAGE = "Registartion Page";
	public static String NAME = "Name";
	public static String EMAIL = "Email";
	public static String PASSWORD = "Password";
	public static String SECURITY_QUESTION = "Security Question";
	public static String ANSWER = "Answer";
	public static String SIGNUP1 = "Signup";
	public static String BACK_TO_LOGIN = "Back To Login";
	public static String SIGNUP2 = "Signup";
	public static String SECURITY_QUESTION1 = "What is your nick name?";
	public static String SECURITY_QUESTION2 = "What your first pet?";
	public static String SECURITY_QUESTION3 = "What was your first car?";
	public static String SECURITY_QUESTION4 = "What is your born place?";
	public static String REGISTRATION = "Registration Done..!";
	public static String ENTER_ALL_FIELD_MESSAGE = "Please enter all Fields..!";

}