package com.hotelmanagement.constants;

public class Adminconstants {
	
	public static String ADMIN_SCREEN="Admin Screen";
	public static String SEARCH_BY_EMAIL="Search By Email";
	public static String SEARCH="Search";
	public static String REFRESH="Refresh";
	public static String BACK_TO_HOME="Back To Home";
	public static String FIRST_HEADER="name";
	public static String SECOND_HEADER="email";
	public static String THIRD_HEADER="user_password";
	public static String FOURTH_HEADER="security_question";
	public static String FIFTH_HEADER="answer";
	public static String SIXTH_HEADER="room_status";
	public static String ENTER_EMAIL="Please enter the email..!";
	public static String RECORD_REFRESH="Record refresh successfully..!";
	public static String SELECT_REFRESH="Please select the single row for refresh..!";

}
