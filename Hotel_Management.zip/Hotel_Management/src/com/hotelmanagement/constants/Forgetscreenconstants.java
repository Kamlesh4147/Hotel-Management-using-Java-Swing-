package com.hotelmanagement.constants;

public class Forgetscreenconstants {
	
	public static String SECURITY_QUESTION1="What is your nick name?";
	
	public static String SECURITY_QUESTION2="What your first pet?";
	
	public static String SECURITY_QUESTION3="What was your first car?";
	
	public static String SECURITY_QUESTION4="What is your born place?";
	
	public static String FRAME_NAME="Forget Password";
	
	public static String EMAIL="Email";
	
	public static String SECURITY_QUESTION="Security Question";
	
	public static String ANSWER="Answer";
	
	public static String CHANGE_PASSWORD="Change Password";
	
	

}
