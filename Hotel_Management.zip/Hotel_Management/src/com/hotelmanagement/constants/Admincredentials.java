package com.hotelmanagement.constants;

public class Admincredentials {
	
	public static String ADMIN_USERNAME="kamlesh@gmail.com";
	public static String ADMIN_PASSWORD="Kamlesh@123";
	

}
