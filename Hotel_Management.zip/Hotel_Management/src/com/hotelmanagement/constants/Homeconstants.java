package com.hotelmanagement.constants;

public class Homeconstants {

	public static String HOME_FRAME = "Home Page";
	public static String MANAGE_ROOM = "Manage Room";
	public static String CUSTOMER_CHECKIN = "Customer Check in";
	public static String CUSTOMER_CHECKOUT = "Customer Check out";
	public static String ADMIN_SCREEN = "Admin Screen";
	public static String LOGOUT = "LOGOUT";
	public static String BACK_TO_HOME = "Back To Home";
	public static String ITEM1_OPEN = "Open";
	public static String ITEM2_OPEN = "Open";
	public static String ITEM3_OPEN = "Open";
	public static String ITEM4_OPEN = "Open";
	public static String LOGOUT_MESSAGE = "Logout Successfully..!";

}
