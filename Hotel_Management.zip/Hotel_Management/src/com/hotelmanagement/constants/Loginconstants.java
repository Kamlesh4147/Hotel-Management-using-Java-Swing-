package com.hotelmanagement.constants;

public class Loginconstants {

	public static String LOGIN_FRAME = "Login Page";
	public static String SIGN_IN = "Sign in";
	public static String EMAIL = "Email: ";
	public static String PASSWORD = "Password: ";
	public static String LOGIN = "Login";
	public static String SIGNUP = "Sin Up Now";
	public static String FORGET_PASS = "Forgot Pass";
	public static String LOGIN_SUCCESSFUL_MESSAGE = "Login Successfully..!";
	public static String WRONG_CREDENTIAL_MESSAGE = "Wrong Email/Password..!";

}
