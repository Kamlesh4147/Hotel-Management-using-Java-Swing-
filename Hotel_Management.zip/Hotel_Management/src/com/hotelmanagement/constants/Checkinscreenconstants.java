package com.hotelmanagement.constants;

public class Checkinscreenconstants {
	
	public static String CUSTOMER_CHECK_IN2="Customer Check In";
	public static String CUSTOMER_NAME="Name";
	public static String MOBILE_NUMBER="Mobile Number";
	public static String EMAIL="Email";
	public static String GENDER="Gender";
	public static String NATIONALITY="Nationality";
	public static String AADHAR_NUMBER="Aadhar Number";
	public static String ADDRESS="Address";
	public static String CHECK_IN_DATE="Check In Date";
	public static String ROOM_TYPE="Room Type";
	public static String BED="bed";
	public static String ROOM_NUMBER="Room Number";
	public static String PRICE="price";
	public static String ALLOTTEE_ROOM="Allottee Room";
	public static String CLEAR="clear";
	public static String CUSTOMER_CHECK_IN1="Customer Check In";
	public static String Check_BACK_TO_HOME="Back To Home";
	public static String GENDER_MALE="Male";
	public static String GENDER_FEMALE="Female";
	public static String AC_TYPE="AC";
	public static String NON_AC_TYPE="NON-AC";
	public static String SINGLE_BED="Single";
	public static String DOUBLE_BED="Double";
	public static String ENTER_ALL_FIELD_MESSAGE="Please enter all fields..!";
	public static String RECORD_SAVED_MESSAGE="Record saved successfully..!";
	
	
}
