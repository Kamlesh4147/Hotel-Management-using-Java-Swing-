package com.hotelmanagement.constants;

public class Logincredentialdetails {

	public static String LOGIN_USERNAME = "kamlesh@gmail.com";
	public static String LOGIN_PASSWORD = "Kamlesh@123";

}
