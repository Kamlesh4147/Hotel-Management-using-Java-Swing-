package com.hotelmanagement.constants;

public class Admincheckconstants {

	public static String ADMIN_VERIFY = "Admin Verify";
	public static String ADMIN_SIGN = "Admin Signin";
	public static String ADMIN_BACK_TO_LOGIN = "Back To Login";
	public static String ADMIN_EMAIL = "Email";
	public static String ADMIN_PASSWORD = "Password";
	public static String ADMIN_LOGIN_BTN = "Login";
	public static String ADMIN_LOGIN_SUCCESS_MESSAGE = "Welcome Kamlesh..!";
	public static String ADMIN_LOGIN_FAILED_MESSAGE = "Wrong Email/Password..!";
	

}
