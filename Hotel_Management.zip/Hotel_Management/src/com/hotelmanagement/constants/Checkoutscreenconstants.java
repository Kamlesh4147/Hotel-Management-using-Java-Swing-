
package com.hotelmanagement.constants;

public class Checkoutscreenconstants {
	
	public static  String CUSTOMER_CHECKOUT="Customer Checkout";
	public static String ROOM_NUMBER="Room Number";
	public static String CHECKOUT_BACK_TO_HOME="Back To Home";
	public static String SEARCH="Search";
	public static String CUSTOMER_NAME="Customer Name";
	public static String PRICE_PER_DAY="Price Per Day";
	public static String CHECK_IN_DATE="Check In Date";
	public static String CUSTOMER_MOBILE_NUMEBR="Customer Mobile Number";
	public static String NUMBER_OF_DAYS="Number Of Days";
	public static String CHECK_OUT_DATE="Check Out Date(Today)";
	public static String EMAIL="Email";
	public static String TOTAL_AMOUNT_TO_COLLECT="Total Amount To Collect";
	public static String CHECKOUT="Check Out";
	public static String CLEAR="Clear";
	public static String FIRST_HEADER="name";
	public static String SECOND_HEADER="room_number";
	public static String THIRD_HEADER="email";
	public static String FOURTH_HEADER="checkInDate";
	public static String FIFTH_HEADER="nationality";
	public static String SIXTH_HEADER="gender";
	public static String SEVENH_HEADER="aadharCard";
	public static String EIGHTH_HEADER="address";
	public static String NINETH_HEADER="address";
	public static String TENTH_HEADER="address";
	public static String ELEVENTH_HEADER="address";
	public static String TWELVETH_HEADER="address";
	
	

}
