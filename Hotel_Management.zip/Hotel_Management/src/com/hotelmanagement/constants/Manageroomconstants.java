package com.hotelmanagement.constants;

public class Manageroomconstants {

	public static String MANAGE_ROOM = "Manage Room";
	public static String ROOM_NUMBER = "Room Number";
	public static String ROOM_TYPE = "Room Type";
	public static String BED = "Bed";
	public static String PRICE = "Price";
	public static String ADD_ROOM = "Add Room";
	public static String AC_ROOM_TYPE = "AC";
	public static String NON_AC_ROOM_TYPE = "NON-AC";
	public static String SINGLE_BED_TYPE = "Single";
	public static String DOUBLE_BED_TYPE = "Double";
	public static String FIRST_HEADER = "room_number";
	public static String SECOND_HEADER = "room_type";
	public static String THIRD_HEADER = "bed";
	public static String FOURTH_HEADER = "price";
	public static String ENTER_ALLFIELD_MESSAGE = "Please enter all field..!";
	public static String RECORD_SAVED_MESSAGE = "Record saved successfully..!";

}
