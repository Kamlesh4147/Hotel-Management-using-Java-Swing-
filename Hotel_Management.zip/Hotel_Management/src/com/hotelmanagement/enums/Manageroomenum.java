package com.hotelmanagement.enums;

public enum Manageroomenum {
	BOOKED, NONBOOKED

}
